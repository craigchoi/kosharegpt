// ==UserScript==
// @name         KoShareGPT
// @namespace    https://www.kosharegpt.com/
// @version      0.2
// @description  ChatGPT와의 대화를 쉽게 공유할 수 있습니다
// @author       kosharegpt.com
// @match        https://chat.openai.com/chat*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==
